let appData = JSON.parse(localStorage.getItem('classSyncData')) || null;
let activeSession = null;
let antiProxyCooldown = false;

// 0. LICENSE KEY VALIDATOR
function validateLicenseKey(courseCode, inputKey) {
  const cleanCourse = courseCode.replace(/\s+/g, '').toUpperCase();
  if (!cleanCourse) return false;

  let hash = 7391; 
  for (let i = 0; i < cleanCourse.length; i++) {
    hash = ((hash << 5) - hash) + cleanCourse.charCodeAt(i);
    hash = hash & hash;
  }
  const expectedKey = 'CS-' + Math.abs(hash).toString().slice(0, 6);
  
  return inputKey.trim().toUpperCase() === expectedKey;
}

// 1. NAVIGATION & SETUP
function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

function handleStart() {
  if (!appData) {
    showScreen('setup-screen');
  } else {
    document.getElementById('login-course-title').innerText = `${appData.course} — ${appData.school}`;
    showScreen('login-screen');
  }
}

document.getElementById('setup-form').addEventListener('submit', function(e) {
  e.preventDefault();
  
  const courseInput = document.getElementById('course-name').value.trim();
  const keyInput = document.getElementById('license-key').value.trim();

  if (!validateLicenseKey(courseInput, keyInput)) {
    alert("❌ Invalid License Key for this Course Code! Contact the developer to purchase an activation key.");
    return;
  }

  const rawList = document.getElementById('student-list-input').value.trim().split('\n');
  
  if (rawList.length > 600) {
    alert("Maximum capacity is 600 students. Please trim the list.");
    return;
  }

  const students = rawList.map((line, index) => {
    const parts = line.split(',');
    const name = parts[0]?.trim() || `Student ${index + 1}`;
    const matric = parts[1]?.trim() || `000${index + 1}`;
    return {
      id: index + 1,
      name: name,
      matric: matric,
      pin: matric.slice(-4),
      records: {}
    };
  });

  appData = {
    lecturer: document.getElementById('lec-name').value.trim(),
    course: courseInput,
    school: document.getElementById('school-name').value.trim(),
    password: document.getElementById('lec-pass').value,
    days: [],
    students: students
  };

  saveData();
  loadDashboard();
});

function verifyLogin() {
  const input = document.getElementById('login-pass-input').value;
  if (input === appData.password) {
    loadDashboard();
  } else {
    alert("Incorrect password!");
  }
}

function loadDashboard() {
  document.getElementById('dash-course').innerText = `${appData.course} (${appData.school})`;
  document.getElementById('dash-lecturer').innerText = `Lecturer: ${appData.lecturer}`;
  document.getElementById('student-count').innerText = appData.students.length;
  renderTable();
  showScreen('dashboard-screen');
}

// 2. LECTURE SESSION & LATE VS PRESENT LOGIC
function startClassSession() {
  const dayNumber = appData.days.length + 1;
  const dateStr = new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });
  const dayLabel = `Day ${dayNumber} (${dateStr})`;

  activeSession = {
    label: dayLabel,
    startTime: Date.now(),
    signedIds: new Set()
  };

  document.getElementById('session-status').innerText = `🟢 LIVE: ${dayLabel}`;
  document.getElementById('btn-start-class').classList.add('hidden');
  document.getElementById('btn-end-class').classList.remove('hidden');
  document.getElementById('kiosk-box').classList.remove('hidden');
  renderKioskList();
}

function renderKioskList(filter = '') {
  const container = document.getElementById('kiosk-student-list');
  container.innerHTML = '';

  appData.students
    .filter(s => s.name.toLowerCase().includes(filter.toLowerCase()) || s.matric.includes(filter))
    .forEach(student => {
      const isSigned = activeSession.signedIds.has(student.id);
      const div = document.createElement('div');
      div.className = 'student-chip';
      div.innerHTML = `
        <div>
          <strong>${student.name}</strong><br>
          <small>${student.matric}</small>
        </div>
        ${isSigned 
          ? `<span>${student.records[activeSession.label]}</span>` 
          : `<button class="btn-small" onclick="signStudent(${student.id})">Sign In</button>`}
      `;
      container.appendChild(div);
    });
}

function filterStudents() {
  renderKioskList(document.getElementById('student-search').value);
}

// 3. ANTI-PROXY SIGN-IN
function signStudent(id) {
  if (antiProxyCooldown) {
    alert("⏳ Anti-Proxy Cooldown: Please wait 5 seconds before the next student signs in.");
    return;
  }

  const student = appData.students.find(s => s.id === id);
  if (activeSession.signedIds.has(id)) {
    alert("Attendance already recorded for this student!");
    return;
  }

  const enteredPin = prompt(`ANTI-PROXY CHECK\nEnter the last 4 digits of Matric No for ${student.name}:`);
  if (enteredPin !== student.pin) {
    alert("❌ Verification failed! You cannot sign in for another student.");
    return;
  }

  const elapsedMinutes = (Date.now() - activeSession.startTime) / 60000;
  const mark = elapsedMinutes <= 15 ? '✅' : '🟡';

  student.records[activeSession.label] = mark;
  activeSession.signedIds.add(id);

  antiProxyCooldown = true;
  setTimeout(() => { antiProxyCooldown = false; }, 5000);

  renderKioskList(document.getElementById('student-search').value);
}

function endClassSession() {
  if (!confirm("End today's class? All unsigned students will be marked Absent (❌).")) return;

  appData.days.push(activeSession.label);
  appData.students.forEach(student => {
    if (!student.records[activeSession.label]) {
      student.records[activeSession.label] = '❌';
    }
  });

  activeSession = null;
  saveData();
  
  document.getElementById('session-status').innerText = "Status: No Active Class";
  document.getElementById('btn-start-class').classList.remove('hidden');
  document.getElementById('btn-end-class').classList.add('hidden');
  document.getElementById('kiosk-box').classList.add('hidden');
  renderTable();
}

// 4. TABLE RENDERING & GRADING SUMMARY
function renderTable(showSummary = false) {
  const thead = document.getElementById('table-head');
  const tbody = document.getElementById('table-body');

  let headHTML = `<tr><th>Student Name</th><th>Matric</th>`;
  appData.days.forEach(day => headHTML += `<th>${day}</th>`);
  if (showSummary) headHTML += `<th>Score %</th><th>Grade</th>`;
  headHTML += `</tr>`;
  thead.innerHTML = headHTML;

  tbody.innerHTML = '';
  appData.students.forEach(student => {
    let rowHTML = `<tr><td>${student.name}</td><td>${student.matric}</td>`;
    let points = 0;

    appData.days.forEach(day => {
      const status = student.records[day] || '-';
      rowHTML += `<td>${status}</td>`;
      if (status === '✅') points += 1;
      if (status === '🟡') points += 0.5;
    });

    if (showSummary && appData.days.length > 0) {
      const pct = Math.round((points / appData.days.length) * 100);
      const grade = pct >= 75 ? 'Eligible (A)' : pct >= 50 ? 'Warning (C)' : 'Barred (F)';
      rowHTML += `<td><strong>${pct}%</strong></td><td>${grade}</td>`;
    }
    rowHTML += `</tr>`;
    tbody.innerHTML += rowHTML;
  });
}

function summarizeSemester() {
  if (appData.days.length === 0) return alert("No lecture days recorded yet.");
  renderTable(true);
  alert("Semester summary & 75% exam eligibility calculated!");
}

// 5. CLASSSYNC HELPER (LOCAL AI ASSISTANT)
function toggleAI() {
  document.getElementById('ai-drawer').classList.toggle('hidden');
}

function askAI() {
  const input = document.getElementById('ai-query');
  const query = input.value.trim().toLowerCase();
  if (!query) return;

  const chat = document.getElementById('ai-chat-box');
  chat.innerHTML += `<div class="ai-msg" style="background:#e2e8f0"><strong>You:</strong> ${input.value}</div>`;
  input.value = '';

  let reply = "I analyzed your attendance records. ";

  if (appData.days.length === 0) {
    reply = "No classes have been completed yet. Start and end a lecture day first so I can analyze records!";
  } else if (query.includes("missed last 3") || query.includes("3 classes")) {
    const last3 = appData.days.slice(-3);
    const chronicAbsentees = appData.students.filter(s => 
      last3.length === 3 && last3.every(d => s.records[d] === '❌')
    );
    reply = chronicAbsentees.length 
      ? `Students who missed all of the last 3 classes (${last3.join(', ')}): ${chronicAbsentees.map(s => s.name).join(', ')}.`
      : `Good news! Nobody missed all 3 of the most recent classes.`;
  } else if (query.includes("failing") || query.includes("75") || query.includes("eligible")) {
    const atRisk = appData.students.filter(s => {
      let pts = 0;
      appData.days.forEach(d => {
        if (s.records[d] === '✅') pts += 1;
        if (s.records[d] === '🟡') pts += 0.5;
      });
      return (pts / appData.days.length) < 0.75;
    });
    reply = `${atRisk.length} student(s) are currently below the 75% threshold: ${atRisk.slice(0, 8).map(s => s.name).join(', ')}${atRisk.length > 8 ? '...' : ''}.`;
  } else {
    const lastDay = appData.days[appData.days.length - 1];
    const presentCount = appData.students.filter(s => s.records[lastDay] === '✅' || s.records[lastDay] === '🟡').length;
    reply += `In your most recent class (${lastDay}), ${presentCount} out of ${appData.students.length} students attended.`;
  }

  chat.innerHTML += `<div class="ai-msg"><strong>ClassSync Helper:</strong> ${reply}</div>`;
  chat.scrollTop = chat.scrollHeight;
}

// 6. EXCEL & PDF EXPORTS FOR HOD
function exportToExcel() {
  const wb = XLSX.utils.table_to_book(document.getElementById('attendance-table'), { sheet: "Attendance" });
  XLSX.writeFile(wb, `${appData.course}_HOD_Attendance.xlsx`);
}

function exportToPDF() {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  doc.text(`${appData.school} - ${appData.course}`, 14, 15);
  doc.setFontSize(10);
  doc.text(`Lecturer: ${appData.lecturer} | Official Attendance Report`, 14, 22);
  doc.autoTable({ html: '#attendance-table', startY: 28 });
  doc.save(`${appData.course}_Attendance_Report.pdf`);
}

function toggleModal(id) { document.getElementById(id).classList.toggle('hidden'); }
function saveData() { localStorage.setItem('classSyncData', JSON.stringify(appData)); }
