// ==========================================
// backup.js - ClassSync JSON Backup & Restore
// ==========================================

function exportJSONBackup() {
  const backupData = {
    app: "ClassSync",
    version: "1.1.0",
    exportedAt: new Date().toISOString(),
    storage: {}
  };

  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    backupData.storage[key] = localStorage.getItem(key);
  }

  if (Object.keys(backupData.storage).length === 0) {
    alert("No attendance or course data found to back up yet.");
    return;
  }

  const jsonString = JSON.stringify(backupData, null, 2);
  const dateStamp = new Date().toISOString().slice(0, 10);
  const fileName = `ClassSync_Backup_${dateStamp}.json`;

  try {
    const blob = new Blob([jsonString], { type: "application/json" });
    const url = URL.createObjectURL(blob);

    const link = document.createElement("a");
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  } catch (err) {
    console.warn("Direct download blocked, opening fallback copy modal:", err);
    showBackupFallbackModal(jsonString, fileName);
  }
}

function importJSONBackup(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function (e) {
    try {
      const parsed = JSON.parse(e.target.result);

      if (parsed.app !== "ClassSync" || !parsed.storage || typeof parsed.storage !== "object") {
        alert("Invalid backup file. Please select a valid ClassSync .json backup.");
        event.target.value = "";
        return;
      }

      const confirmRestore = confirm(
        `Restore backup from ${new Date(parsed.exportedAt).toLocaleString()}?\n\nThis will replace your current attendance records on this device.`
      );

      if (!confirmRestore) {
        event.target.value = "";
        return;
      }

      localStorage.clear();
      Object.keys(parsed.storage).forEach((key) => {
        localStorage.setItem(key, parsed.storage[key]);
      });

      alert("Backup restored successfully! Reloading dashboard...");
      window.location.reload();
    } catch (err) {
      alert("Failed to read backup file. Make sure the JSON file is not corrupted.");
      console.error("Backup restore error:", err);
    }
  };

  reader.readAsText(file);
}

// Fallback modal if Android WebView restricts blob file downloads
function showBackupFallbackModal(jsonString, fileName) {
  let modal = document.getElementById("backup-fallback-modal");
  if (!modal) {
    modal = document.createElement("div");
    modal.id = "backup-fallback-modal";
    modal.style.cssText =
      "position:fixed;inset:0;background:rgba(0,0,0,0.65);display:flex;align-items:center;justify-content:center;z-index:9999;padding:16px;";
    modal.innerHTML = `
      <div style="background:#fff;border-radius:12px;padding:18px;max-width:480px;width:100%;box-shadow:0 10px 25px rgba(0,0,0,0.2);">
        <h3 style="margin:0 0 6px;">Copy Backup Data</h3>
        <p style="font-size:13px;color:#555;margin:0 0 10px;">Save this text as <strong>${fileName}</strong> or paste it on another device:</p>
        <textarea id="backup-fallback-text" readonly style="width:100%;height:160px;font-family:monospace;font-size:12px;padding:8px;border:1px solid #ccc;border-radius:8px;"></textarea>
        <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:12px;">
          <button type="button" id="copy-backup-btn" class="btn-primary">Copy JSON</button>
          <button type="button" onclick="document.getElementById('backup-fallback-modal').remove()" class="btn-secondary">Close</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
  }
  document.getElementById("backup-fallback-text").value = jsonString;
  document.getElementById("copy-backup-btn").onclick = () => {
    navigator.clipboard.writeText(jsonString);
    alert("Backup JSON copied to clipboard!");
  };
}
